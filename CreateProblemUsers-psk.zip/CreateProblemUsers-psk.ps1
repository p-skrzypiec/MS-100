# This script will make the following changes to users in AD DS:
#   Update the UserPrincipalName for 'CJBarela' to include an extra '@' character
#   Update the emailAddress for 'DJCarrera' to 'DJCarrera@psk.ms-100.site'
#   Update the emailAddress for 'MRCorbett' to 'MRCorbett@psk.ms-100.site'
#   Update the emailAddress for 'LJCrowley' to �LJCrowley @psk.ms-100.site�
#   Update the emailAddress for 'RKCuneo' to � �

# Update UPN for 'CJBarela'
$upn = Get-ADUser CJBarela | Select UserPrincipalName
If ($upn.UserPrincipalName -notlike "*@@*"){
	$arrupn = $upn.UserPrincipalName -split '@'
	$newUPN = $arrUPN[0] + "@@" + $arrUPN[1]
	Set-ADUser CJBarela -UserPrincipalName $newUPN
	Write-Host "CJBarela was updated successfully"
} Else {
	Write-Host "CJBarela was ALREADY updated"
}

# Update emailAddress for 'DJCarrera'
$emailDJCarrera = Get-ADUser DJCarrera -Properties emailAddress | Select emailAddress
If ($emailDJCarrera.emailAddress -notlike "DJCarrera@psk.ms-100.site"){
	Set-ADUser DJCarrera -emailAddress DJCarrera@psk.ms-100.site
	Write-Host "DJCarrera was updated successfully"
} Else {
	Write-Host "DJCarrera was ALREADY updated"
}

# Update emailAddress for 'MRCorbett'
$emailMRCorbett = Get-ADUser MRCorbett -Properties emailAddress | Select emailAddress
If ($emailMRCorbett.emailAddress -notlike "DJCarrera@psk.ms-100.site"){
	Set-ADUser MRCorbett -emailAddress DJCarrera@psk.ms-100.site
	Write-Host "MRCorbett was updated successfully"
} Else {
	Write-Host "MRCorbett was ALREADY updated"
}

# Update emailAddress for 'LJCrowley'
$emailLJCrowley = Get-ADUser LJCrowley -Properties emailAddress | Select emailAddress
If ($emailLJCrowley.emailAddress -notlike "LJCrowley @psk.ms-100.site"){
	Set-ADUser LJCrowley -emailAddress "LJCrowley @psk.ms-100.site"
	Write-Host "LJCrowley was updated successfully"
} Else {
	Write-Host "LJCrowley was ALREADY updated"
}

# Update emailAddress for 'RKCuneo'
$emailRKCuneo = Get-ADUser RKCuneo -Properties emailAddress | Select emailAddress
If ($emailRKCuneo.emailAddress -notlike " "){
	Set-ADUser RKCuneo -emailAddress " "
	Write-Host "RKCuneo was updated successfully"
} Else {
	Write-Host "RKCuneo was already updated"
}

